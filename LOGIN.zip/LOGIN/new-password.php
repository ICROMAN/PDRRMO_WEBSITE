<?php
  require_once "controllerUserData.php"; 
  $upload_dir = '../USER/ADMIN/PDRRMO-FUNCTIONALITIES/Announcement_record/uploads/';
  $upload_dir = '../USER/SUPERUSER/uploads/';
?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: login-user.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Create a New Password</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="icon" type="image/ico" href="pdrrmo.png">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <?php
    $sql = "select * from public_info";
    $result = mysqli_query($con, $sql);
    if(mysqli_num_rows($result)){
      while($row = mysqli_fetch_assoc($result)){
  ?>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="../index.php" class="logo d-flex align-items-center">
        <img src="<?php echo $upload_dir.$row['image'] ?>" alt="">
        <span><?php echo $row['system_short'] ?></span>
      </a>

      <nav id="navbar" class="navbar text-uppercase">
        <ul>
          <li><a class="nav-link scrollto" href="../index.php#about">About</a></li>
          <li><a href="../index.php#recent-blog-posts">Announcement</a></li>
          <!-- <li class="dropdown"><a href="maps.php"><span>Maps</span></i></a>
            <ul>
              <li><a href="maps.php #laguna">PROVINCE OF LAGUNA</a></li>
              <li><a href="maps.php #evacuation">LAGUNA EVACUATION SITES</a></li>
              <li><a href="maps.php #hospital">LAGUNA HOSPITALS</a></li>
            </ul>
          </li> -->
          <li><a class="nav-link scrollto" href="../index.php#services">Services</a></li>
          <li><a class="nav-link scrollto" href="../index.php#team">Team</a></li>
          <li><a class="nav-link scrollto" href="../index.php#contact">Contact</a></li>
          <li><a href="../LOGIN/login-user.php">Login</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up" style="font-size: 100px; font-weight: 800;"><?php echo $row['system_short'] ?></h1>
          <h2 data-aos="fade-up" data-aos-delay="400"><?php echo $row['system_title'] ?></h2>
        </div>

        <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
          <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-3 form">
                <form action="new-password.php" method="POST" autocomplete="off">
                    <div class="illustration text-center "><img src="pdrrmo.png" style="width: 120px; height: 120px;"></div>
                    <h4 class="text-center" style="font-weight: 600;">Create a New Password</h4>
                    <?php 
                    if(isset($_SESSION['info'])){
                        ?>
                        <div class="alert alert-success text-center">
                            <?php echo $_SESSION['info']; ?>
                        </div>
                        <?php
                    }
                    ?>
                    <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Create new password" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="cpassword" placeholder="Confirm your password" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="change-password" value="Change">
                    </div>
                </form>
            </div>
        </div>
    </div>
        </div>
      </div>
    </div>


  </section><!-- End Hero -->
    <?php
          }
        }
      ?>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="ri-arrow-up-s-line"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>