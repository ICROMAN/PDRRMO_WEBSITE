<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$userName=$_POST['name'];
		$userEmail=$_POST['email'];
		$subject=$_POST['subject'];
		$message=$_POST['message'];
		
		$sql = "INSERT INTO `contact_report`( `name`, `email`,`subject`,`message`) 
		VALUES ('$userName','$userEmail','$subject','$message')";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('Public Access', 'Added Contact Report')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}