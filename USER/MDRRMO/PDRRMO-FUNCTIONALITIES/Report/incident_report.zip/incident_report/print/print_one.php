<?php
require('fpdf/fpdf.php');
include('config.php');
$id = $_GET['id'];
$pdf = new FPDF();
///var_dump(get_class_methods($pdf));

$pdf->AddPage();

// Logo
    $pdf->Image('laguna.png',11,12,28 );
    $pdf->Image('pdrrmo.png',169,10,33 );
    $pdf->Image('photo-holder.jpg',-10,41,230 );
    
    // Arial bold 15
    $pdf->SetFont('Arial','B',10);
    // Move to the right
    $pdf->Cell(80);
    // Title
    $pdf->cell(30,20,'PROVINCE OF LAGUNA',0,0,'C');
    $pdf->cell(-25,30,'PROVINCIAL DISASTER RISK REDUCTION AND MANAGEMENT OFFICE',0,0,'C');
    $pdf->cell(40,40,'LAGUNA PREPAREDNESS OPERATION CENTER',0,0,'C');
    $pdf->cell(-50,50,'Santa Cruz, Laguna',0,0,'C');
    

    // // Line break

  	$query="SELECT * FROM incident_records WHERE id = '$id'";
	$result = mysqli_query($conn, $query);
	while($row = mysqli_fetch_array($result)){

	$pdf->SetFont('Arial','B',20);
	$pdf->Ln(10);
    $pdf->cell(191,60,'INCIDENT RECORD',0,0,'C');

	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(45);
	$pdf->cell(186,10,'Incident Location',1,0,'C'); 

	$pdf->Ln(10);
	$pdf->cell(93,7,'City/Municipalities',1,0,'C');
	$pdf->cell(93,7,'Barangay',1,0,'C');

	$pdf->SetFont('Arial','',12);

	$pdf->Ln(7);
	$pdf->cell(93,15,$row['municipality'],1,0,'C');
	$pdf->cell(93,15,$row['baranggay'],1,0,'C');

	$pdf->Ln(15);
    $pdf->SetFont('Arial','B',12);
	$pdf->cell(44,7,'Incident ID ',1,0,'C'); 
	$pdf->cell(71,7,'Incident Date',1,0,'C'); 
	$pdf->cell(71,7,'Incident Time',1,0,'C'); 


	$pdf->SetFont('Arial','',12);


	$pdf->Ln(7);
	$pdf->cell(44,15,$row['id'],1,0,'C'); 
	$pdf->cell(71,15,$row['incident_date'],1,0,'C'); 
	$pdf->cell(71,15,$row['incident_time'],1,0,'C'); 

	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(15);
	$pdf->cell(93,7,'Casualties',1,0,'C'); 
	$pdf->cell(93,7,'Reported By',1,0,'C'); 


	$pdf->SetFont('Arial','',12);
	$pdf->Ln(7);
	$pdf->cell(93,15,$row['casualties'],1,0,'C'); 
	$pdf->cell(93,15,$row['reported'],1,0,'C');  

	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(15);
	$pdf->cell(44,7,'Operation',1,0,'C'); 
	$pdf->cell(71,7,'Incident Type',1,0,'C'); 
	$pdf->cell(71,7,'This is Connected to:',1,0,'C'); 


	$pdf->SetFont('Arial','',12);
	$pdf->Ln(7);
	$pdf->cell(44,15,$row['operation_type'],1,0,'C'); 
	$pdf->cell(71,15,$row['incident_type'],1,0,'C'); 
	$pdf->cell(71,15,$row['connected'],1,0,'C'); 


	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(15);
	$pdf->cell(186,10,'Narrative',1,0,'C'); 
	

	$pdf->SetFont('Arial','',11); 
	$pdf->Ln(10);
	$pdf->cell(186,30,$row['narrative'],1,0,'C'); 
	$pdf->Ln(2);
	$pdf->cell(12,10,'',0,0,'L');

	$pdf->SetFont('Arial','B',12);
	$pdf->Ln(50);
	$pdf->cell(120,7,'Received by:',0,0,'R');

	$pdf->Ln(15);
	$pdf->cell(180,7,'_________________________',0,0,'R');
	

	$pdf->Ln(7);
	$pdf->cell(180,7,'Printed Name over Signature',0,0,'R');
}

$pdf->Output();

?>