<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$incident_date=$_POST['incident_date'];
		$incident_time=$_POST['incident_time'];
		$municipality=$_POST['municipality'];
		$baranggay=$_POST['baranggay'];
		$damages=$_POST['damages'];
		$casualties=$_POST['casualties'];
		$reported=$_POST['reported'];
		$operation_type=$_POST['operation_type'];
		$incident_type=$_POST['incident_type'];
		$connected=$_POST['connected'];
		$narrative=$_POST['narrative'];
		$sql = "INSERT INTO `incident_records`(`incident_date`, `incident_time`, `municipality`, `baranggay`, `casualties`, `reported`, `operation_type`, `incident_type`, `connected`, `narrative`) 
		VALUES ('$incident_date','$incident_time','$municipality','$baranggay', '$casualties', '$reported', '$operation_type','$incident_type','$connected','$narrative')";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('MDRRMO', 'Added Incident Report Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$incident_date=$_POST['incident_date'];
		$incident_time=$_POST['incident_time'];
		$municipality=$_POST['municipality'];
		$baranggay=$_POST['baranggay'];
		$damages=$_POST['damages'];
		$casualties=$_POST['casualties'];
		$reported=$_POST['reported'];
		$operation_type=$_POST['operation_type'];
		$incident_type=$_POST['incident_type'];
		$connected=$_POST['connected'];
		$narrative=$_POST['narrative'];
		$sql = "UPDATE `incident_records` SET `incident_date`='$incident_date',`incident_time`='$incident_time',`municipality`='$municipality',`baranggay`='$baranggay',`casualties`='$casualties',`reported`='$reported',`operation_type`='$operation_type',`incident_type`='$incident_type',`connected`='$connected',`narrative`='$narrative' WHERE id=$id";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('MDRRMO', 'Updated Incident Report Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_report` (incident_date, incident_time, municipality, baranggay, casualties, reported, operation_type, incident_type, connected, narrative)
				SELECT incident_date, incident_time, municipality, baranggay, casualties, reported, operation_type, incident_type, connected, narrative FROM incident_records WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('MDRRMO', 'Archived Incident Report Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `incident_records` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM incident_records WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('MDRRMO', 'Deleted Incident Report Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

