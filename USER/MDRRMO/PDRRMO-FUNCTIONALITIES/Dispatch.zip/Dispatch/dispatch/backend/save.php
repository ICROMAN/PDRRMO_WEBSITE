<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$dispatch_name=$_POST['dispatch_name'];
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$dispatch_total=$_POST['dispatch_total'];
		$dispatch_location=$_POST['dispatch_location'];
		$sql = "INSERT INTO `dispatch`( `dispatch_name`, `fname`, `lname`, `dispatch_total`, `dispatch_location`) 
		VALUES ('$dispatch_name','$fname','$lname','$dispatch_total','$dispatch_location')";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('MDRRMO', 'Added Dispatch Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$dispatch_name=$_POST['dispatch_name'];
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$dispatch_total=$_POST['dispatch_total'];
		$dispatch_location=$_POST['dispatch_location'];
		$dispatch_status=$_POST['dispatch_status'];
		$sql = "UPDATE `dispatch` SET `dispatch_name`='$dispatch_name',`fname`='$fname',`lname`='$lname',`dispatch_location`='$dispatch_location',`dispatch_total`='$dispatch_total',`dispatch_status`='$dispatch_status' WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('MDRRMO', 'Updated Dispatch Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_dispatch` (dispatch_name, fname, lname, dispatch_total, dispatch_location, dispatch_status)
				SELECT dispatch_name, fname, lname, dispatch_total, dispatch_location, dispatch_status FROM dispatch WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('MDRRMO', 'Archived Dispatch Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `dispatch` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM dispatch WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('MDRRMO', 'Deleted Dispatch Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

