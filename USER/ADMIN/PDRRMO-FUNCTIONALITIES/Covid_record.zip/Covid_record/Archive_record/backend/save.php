<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];

		$sql = "INSERT INTO `covid_records` (municipality_cases, active_cases, recovered_cases, expired_cases, total_cases, quarantine_facilities, individual_male, individual_female, total_individuals)
				SELECT municipality_cases, active_cases, recovered_cases, expired_cases, total_cases, quarantine_facilities, individual_male, individual_female, total_individuals FROM archived_covid WHERE id=$id";

		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Restored Covid Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `archived_covid` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];

		$sql = "DELETE FROM `archived_covid` WHERE id=$id ";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Deleted Covid Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

