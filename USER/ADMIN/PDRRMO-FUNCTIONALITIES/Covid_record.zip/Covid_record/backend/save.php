<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$municipality_cases=$_POST['municipality_cases'];
		$active_cases=$_POST['active_cases'];
		$recovered_cases=$_POST['recovered_cases'];
		$expired_cases=$_POST['expired_cases'];
		$total_cases=$_POST['total_cases'];
		$quarantine_facilities=$_POST['quarantine_facilities'];
		$individual_male=$_POST['individual_male'];
		$individual_female=$_POST['individual_female'];
		$total_individuals=$_POST['total_individuals'];
		$sql = "INSERT INTO `covid_records`( `municipality_cases`, `active_cases`,`recovered_cases`,`expired_cases`,`total_cases`,`quarantine_facilities`,`individual_male`,`individual_female`,`total_individuals`) 
		VALUES ('$municipality_cases','$active_cases','$recovered_cases','$expired_cases','$total_cases','$quarantine_facilities','$individual_male','$individual_female','$total_individuals')";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Added Covid Cases Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$municipality_cases=$_POST['municipality_cases'];
		$active_cases=$_POST['active_cases'];
		$recovered_cases=$_POST['recovered_cases'];
		$expired_cases=$_POST['expired_cases'];
		$total_cases=$_POST['total_cases'];
		$quarantine_facilities=$_POST['quarantine_facilities'];
		$individual_male=$_POST['individual_male'];
		$individual_female=$_POST['individual_female'];
		$total_individuals=$_POST['total_individuals'];
		$sql = "UPDATE `covid_records` SET `municipality_cases`='$municipality_cases',`active_cases`='$active_cases',`recovered_cases`='$recovered_cases',`expired_cases`='$expired_cases',`total_cases`='$total_cases',`quarantine_facilities`='$quarantine_facilities',`individual_male`='$individual_male',`individual_female`='$individual_female',`total_individuals`='$total_individuals'  WHERE id=$id";
		$result = mysqli_query($conn, $sql);
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Updated Covid Cases Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];

		$sql = "INSERT INTO `archived_covid` (municipality_cases, active_cases, recovered_cases, expired_cases, total_cases, quarantine_facilities, individual_male, individual_female, total_individuals)
				SELECT municipality_cases, active_cases, recovered_cases, expired_cases, total_cases, quarantine_facilities, individual_male, individual_female, total_individuals FROM covid_records WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Archived Covid Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `covid_records` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM covid_records WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>