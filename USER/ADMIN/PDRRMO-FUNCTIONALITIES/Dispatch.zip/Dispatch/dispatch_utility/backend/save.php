<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$dispatch_name=$_POST['dispatch_name'];
		$sql = "INSERT INTO `dispatch_utility`( `dispatch_name`) 
		VALUES ('$dispatch_name')";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Added Dispatch Utility Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$dispatch_name=$_POST['dispatch_name'];
		$sql = "UPDATE `dispatch_utility` SET `dispatch_name`='$dispatch_name' WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Updated Dispatch Utility Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_utility` (dispatch_name, dispatch_status)
				SELECT dispatch_name, dispatch_status FROM dispatch_utility WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Archived Dispatch Utility Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `dispatch_utility` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM dispatch_utility WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Deleted Dispatch Utility Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

