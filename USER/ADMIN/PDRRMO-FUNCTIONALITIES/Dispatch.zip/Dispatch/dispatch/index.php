<?php
include 'backend/database.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PDRRMO | Dispatch</title>
    <link rel="icon" type="image/ico" href="../../../../../pdrrmo.png">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="ajax/ajax.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800;900&display=swap');
        html,body{
            font-family: 'Montserrat', sans-serif;
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php 
            include_once "sidebar.php";
         ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter count"></span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                            </div>
                        </li>
                        
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">PDRRMO ACCOUNT</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">


                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h3 class="m-0 font-weight-bold text-primary">Manage Dispatch Records
                            <div style='float:right;'>
                                <a href="#addAmbulanceModal" class="btn small btn-primary btn-icon-split" data-toggle="modal"> 
                                    <span class="icon text-white-50">
                                        <i class="fas fa-plus"></i>
                                    </span>
                                    <span class="text">Add New Record</span>
                                </a>
                                <div class="dropdown no-arrow" style='float:right; margin-top: 5px; margin-left: 15px;'>
                                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                        aria-labelledby="dropdownMenuLink">
                                        <div class="dropdown-header">Dropdown Action</div>
                                        <a class="dropdown-item" href="date/index.php">
                                            <i class="fas fa-filter fa-sm fa-fw mr-2 text-gray-400"></i>
                                            Filter Records
                                        </a>
                                        <a class="dropdown-item" href="Archive_record/index.php">
                                            <i class="fas fa-archive fa-sm fa-fw mr-2 text-gray-400"></i>
                                            Archived Records
                                        </a>
                                    </div>
                                </div>
                            </div></h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Location</th>
                                            <th>Total Dispatch Utility</th>
                                            <th>Availability</th>
                                            <th>Department Personnel</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>ID</th>
                                            <th>Location</th>
                                            <th>Total Dispatch Utility</th>
                                            <th>Availability</th>
                                            <th>Department Personnel</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $result = mysqli_query($conn,"SELECT * FROM dispatch");
                                            $i=1;
                                            while($row = mysqli_fetch_array($result)) {
                                        ?>
                                        <tr id="<?php echo $row["id"]; ?>">
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $row["dispatch_location"]; ?></td>
                                            <td><?php echo $row["dispatch_total"]; ?> <?php echo $row["dispatch_name"]; ?></td>
                                            <td><?php echo $row["dispatch_status"]; ?></td>
                                            <td><?php echo $row["fname"]; ?> <?php echo $row["lname"]; ?></td>
                                            <td>
                                                <button class="btn btn-warning btn-sm" type="button"><a href="#editAmbulanceModal" class="edit" data-toggle="modal">
                                                    <i class="fas fa-edit update text-white" data-toggle="tooltip" 
                                                    data-id="<?php echo $row["id"]; ?>"
                                                    data-dispatch="<?php echo $row["dispatch_name"]; ?>"
                                                    data-fname="<?php echo $row["fname"]; ?>"
                                                    data-lname="<?php echo $row["lname"]; ?>"
                                                    data-total="<?php echo $row["dispatch_total"]; ?>"
                                                    data-location="<?php echo $row["dispatch_location"]; ?>"
                                                    data-status="<?php echo $row["dispatch_status"]; ?>"
                                                    title="Edit"></i>
                                                </a></button>
                                                <button class="btn btn-danger btn-sm" type="button"><a href="#deleteAmbulanceModal" class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="fas fa-archive text-white" data-toggle="tooltip" 
                                                 title="Archive"></i></a></button>
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                        }
                                        ?>  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Add Modal HTML -->
                    <div id="addAmbulanceModal" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form id="ambulance_form">
                                    <div class="modal-header">                      
                                        <h4 class="modal-title">Add Dispatch Record</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">                    
                                        <div class="row">
                                            <div class="col">
                                                <div class="form-group">
                                                    <label>Personnel First Name</label>
                                                    <input type="text" id="fname" name="fname" class="form-control" required>
                                                </div>
                                            </div>

                                            <div class="col">
                                                <div class="form-group">
                                                    <label>Personnel Last Name</label>
                                                    <input type="text" id="lname" name="lname" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Total Number of Utilities</label>
                                            <input type="Number" id="total" name="dispatch_total" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Dispatch Utility</label>
                                            <select type="text" id="dispatch" name="dispatch_name" class="form-control" required>
                                                <option value="">Select Utility</option>
                                                <?php
                                                  $sql = "SELECT * FROM dispatch_utility";
                                                  $result = $conn->query($sql);

                                                  if ($result->num_rows > 0) {
                                                      while ($row = $result->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $row['dispatch_name']?>"><?php echo $row['dispatch_name']?></option>
                                                <?php 
                                                    }
                                                }
                                                ?>
                                                <script>
                                                  function getSelectedIndex(j) {
                                                    var opts = document.getElementById("dispatch_utility").options;
                                                    for(var i = 0; i < opts.length; i++) {
                                                        if(opts[i].innerText == j.toString()) {  
                                                            document.getElementById("dispatch_utility").selectedIndex = i;        
                                                            break;
                                                        }
                                                    }
                                                  }
                                                </script>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Municipality</label>
                                            <select type="text" id="location" name="dispatch_location" class="form-control" required>
                                                <option value="">Select Municipality</option>
                                                <?php
                                                  $sql = "SELECT * FROM municipality";
                                                  $result = $conn->query($sql);

                                                  if ($result->num_rows > 0) {
                                                      while ($row = $result->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $row['municipality_name']?>"><?php echo $row['municipality_name']?></option>
                                                <?php 
                                                    }
                                                }
                                                ?>
                                                <script>
                                                  function getSelectedIndex(j) {
                                                    var opts = document.getElementById("municipality").options;
                                                    for(var i = 0; i < opts.length; i++) {
                                                        if(opts[i].innerText == j.toString()) {  
                                                            document.getElementById("municipality").selectedIndex = i;        
                                                            break;
                                                        }
                                                    }
                                                  }
                                                </script>
                                            </select>
                                        </div>                
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" value="1" name="type">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <button type="button" class="btn btn-primary" id="btn-add" data-dismiss="modal">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Edit Modal HTML -->
                    <div id="editAmbulanceModal" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <?php
                                $result = mysqli_query($conn,"SELECT * FROM dispatch");
                                    $i=1;
                                    while($row = mysqli_fetch_array($result)) {
                                ?>
                                <form id="update_form">
                                    <div class="modal-header">                      
                                        <h4 class="modal-title">Edit Dispatch Record</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" id="id_u" name="id" class="form-control" required>
                                        <div class="row">
                                            <div class="col">
                                                <div class="form-group">
                                                    <label>Personnel First Name</label>
                                                    <input type="text" id="fname_u" name="fname" value="<?php echo $row["fname"]; ?>" class="form-control" required>
                                                </div>
                                            </div>

                                            <div class="col">
                                                <div class="form-group">
                                                    <label>Personnel Last Name</label>
                                                    <input type="text" id="lname_u" name="lname" value="<?php echo $row["lname"]; ?>"class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Total Number of Utilities</label>
                                            <input type="Number" id="total_u" name="dispatch_total" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Dispatch Utility</label>
                                            <select type="text" id="dispatch_u" name="dispatch_name" class="form-control" required>
                                                <option value="">Select Utility</option>
                                                <?php
                                                  $sql = "SELECT * FROM dispatch_utility";
                                                  $result = $conn->query($sql);

                                                  if ($result->num_rows > 0) {
                                                      while ($row = $result->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $row['dispatch_name']?>"><?php echo $row['dispatch_name']?></option>
                                                <?php 
                                                    }
                                                }
                                                ?>
                                                <script>
                                                  function getSelectedIndex(j) {
                                                    var opts = document.getElementById("dispatch_utility").options;
                                                    for(var i = 0; i < opts.length; i++) {
                                                        if(opts[i].innerText == j.toString()) {  
                                                            document.getElementById("dispatch_utility").selectedIndex = i;        
                                                            break;
                                                        }
                                                    }
                                                  }
                                                </script>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Municipality</label>
                                            <select type="text" id="location_u" name="dispatch_location" class="form-control" required>
                                                <option value="">Select Municipality</option>
                                                <?php
                                                  $sql = "SELECT * FROM municipality";
                                                  $result = $conn->query($sql);

                                                  if ($result->num_rows > 0) {
                                                      while ($row = $result->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $row['municipality_name']?>"><?php echo $row['municipality_name']?></option>
                                                <?php 
                                                    }
                                                }
                                                ?>
                                                <script>
                                                  function getSelectedIndex(j) {
                                                    var opts = document.getElementById("municipality").options;
                                                    for(var i = 0; i < opts.length; i++) {
                                                        if(opts[i].innerText == j.toString()) {  
                                                            document.getElementById("municipality").selectedIndex = i;        
                                                            break;
                                                        }
                                                    }
                                                  }
                                                </script>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Availability</label>
                                            <select type="text" id="status_u" name="dispatch_status" class="form-control" required>
                                                <option value="">Select Availability</option>
                                                <option value="Available">Available</option>
                                                <option value="Occupied">Occupied</option>
                                            </select>
                                        </div>                                  
                                    </div>
                                    <div class="modal-footer">
                                    <input type="hidden" value="2" name="type">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <button type="button" class="btn btn-primary" id="update" data-dismiss="modal">Update</button>
                                    </div>
                                </form>
                                <?php
                                    $i++;
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>
                    <!-- Delete Modal HTML -->
                    <div id="deleteAmbulanceModal" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form>
                                        
                                    <div class="modal-header">                      
                                        <h4 class="modal-title">Delete Dispatch Record</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" id="id_d" name="id" class="form-control">                  
                                        <h5>Are you sure you want to delete these Records?</h5>
                                        <p class="text-warning"><small>This action cannot be undone.</small></p>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <button type="button" class="btn btn-danger" id="delete" data-dismiss="modal">Archive</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-default" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="../../../../../LOGIN/logout-user.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
         
         function load_unseen_notification(view = '')
         {
          $.ajax({
           url:"fetch.php",
           method:"POST",
           data:{view:view},
           dataType:"json",
           success:function(data)
           {
            $('.dropdown-list').html(data.notification);
            if(data.unseen_notification > 0)
            {
             $('.count').html(data.unseen_notification);
            }
           }
          });
         }
         
         load_unseen_notification();
         
         $(document).on('click', '.dropdown-toggle', function(){
          $('.count').html('');
          load_unseen_notification('yes');
         });
         
         setInterval(function(){ 
          load_unseen_notification();; 
         }, 5000);
         
        });
    </script>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>