<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$municipality=$_POST['municipality'];
		$evacs_location=$_POST['evacs_location'];
		$evacs_status=$_POST['evacs_status'];
		$floor_capacity=$_POST['floor_capacity'];
		$evacs_availability=$_POST['evacs_availability'];
		$evacs_remarks=$_POST['evacs_remarks'];
		$floor_area=$_POST['floor_area'];
		$wash_status=$_POST['wash_status'];
		$sql = "INSERT INTO `evacuation_records`( `municipality`, `evacs_location`,`evacs_status`,`floor_capacity`,`evacs_availability`,`evacs_remarks`,`floor_area`,`wash_status`) 
		VALUES ('$municipality','$evacs_location','$evacs_status','$floor_capacity','$evacs_availability','$evacs_remarks','$floor_area','$wash_status')";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Added Evacuation Facility Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$municipality=$_POST['municipality'];
		$evacs_location=$_POST['evacs_location'];
		$evacs_status=$_POST['evacs_status'];
		$floor_capacity=$_POST['floor_capacity'];
		$evacs_availability=$_POST['evacs_availability'];
		$evacs_remarks=$_POST['evacs_remarks'];
		$floor_area=$_POST['floor_area'];
		$wash_status=$_POST['wash_status'];
		$sql = "UPDATE `evacuation_records` SET `municipality`='$municipality',`evacs_location`='$evacs_location',`evacs_status`='$evacs_status',`floor_capacity`='$floor_capacity',`evacs_availability`='$evacs_availability',`evacs_remarks`='$evacs_remarks',`floor_area`='$floor_area',`wash_status`='$wash_status' WHERE id=$id";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Updated Evacuation Facility Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_evacuation` (municipality, evacs_location, evacs_status, floor_capacity, evacs_availability, evacs_remarks, floor_area, wash_status)
				SELECT municipality, evacs_location, evacs_status, floor_capacity, evacs_availability, evacs_remarks, floor_area, wash_status FROM evacuation_records WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Archived Evacuation Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `evacuation_records` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM evacuation_records WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Deleted Evacuation Facility Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>