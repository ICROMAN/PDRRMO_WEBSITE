<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$baranggay=$_POST['baranggay'];
		$sql = "INSERT INTO `baranggay`( `baranggay`) 
		VALUES ('$baranggay')";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Added Baranggay Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$baranggay=$_POST['baranggay'];
		$sql = "UPDATE `baranggay` SET `baranggay`='$baranggay' WHERE id=$id";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Updated Baranggay Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_baranggay` (baranggay, baranggay_status)
				SELECT baranggay, baranggay_status FROM baranggay WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Archived Baranggay Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `baranggay` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM baranggay WHERE id in ($id)";

		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Deleted Baranggay Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

