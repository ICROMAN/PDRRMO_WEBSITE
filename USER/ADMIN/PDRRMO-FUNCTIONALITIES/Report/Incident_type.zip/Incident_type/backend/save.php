<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$incident=$_POST['incident'];
		$sql = "INSERT INTO `incident_type`( `incident`) 
		VALUES ('$incident')";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Added Incident Type Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$incident=$_POST['incident'];
		$sql = "UPDATE `incident_type` SET `incident`='$incident' WHERE id=$id";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Updated Incident Type Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_incident` (incident, incident_status)
				SELECT incident, incident_status FROM incident_type WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Archived Incident Type Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `incident_type` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM incident_type WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Deleted Incident Type Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

