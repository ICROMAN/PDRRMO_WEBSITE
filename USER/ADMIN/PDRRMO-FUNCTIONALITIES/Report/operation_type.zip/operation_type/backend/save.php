<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$operation=$_POST['operation'];
		$sql = "INSERT INTO `operation_type`( `operation`) 
		VALUES ('$operation')";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Added Operation Type Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$operation=$_POST['operation'];
		$sql = "UPDATE `operation_type` SET `operation`='$operation' WHERE id=$id";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Updated Operation Type Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "INSERT INTO `archived_operation` (operation, operation_status)
				SELECT operation, operation_status FROM operation_type WHERE id=$id";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('PDRRMO', 'Archived Operation Type Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `operation_type` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM operation_type WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);
		
		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Deleted Operation Type Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

