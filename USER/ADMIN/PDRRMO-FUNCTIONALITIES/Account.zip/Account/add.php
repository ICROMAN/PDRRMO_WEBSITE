<?php
  require_once('db.php');
  $upload_dir = '../../../../SUPERUSER/Functionalities/Account/uploads/';

  if (isset($_POST['Submit'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    // $password = $_POST['password'];
    $role = $_POST['role'];

    $imgName = $_FILES['image']['name'];
		$imgTmp = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];

    if(empty($fname)){
			$errorMsg = 'Please input First Name';
		}elseif(empty($lname)){
			$errorMsg = 'Please input Last Name';	
		}elseif(empty($email)){
			$errorMsg = 'Please input Email Address';
		// }elseif(empty($password)){
		// 	$errorMsg = 'Please input Password';
		}elseif(empty($role)){
			$errorMsg = 'Please input User Role';	
		}else{

			$imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));

			$allowExt  = array('jpeg', 'jpg', 'png', 'gif');

			$userPic = time().'_'.rand(1000,9999).'.'.$imgExt;

			if(in_array($imgExt, $allowExt)){

				if($imgSize < 5000000){
					move_uploaded_file($imgTmp ,$upload_dir.$userPic);
				}else{
					$errorMsg = 'Image too large';
				}
			}else{
				$errorMsg = 'Please select a valid image';
			}
		}


		if(!isset($errorMsg)){
			$sql = "insert into usertable (fname, lname, email, role, image)
					values('".$fname."', '".$lname."', '".$email."', '".$role."', '".$userPic."')";
			$result = mysqli_query($conn, $sql);

			$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
			VALUES ('PDRRMO', 'Added New Account Record')";
			$result1 = mysqli_query($conn, $sql);

			if ($result) {
				$successMsg = 'New record added successfully';
				header('Location: index.php');
			}else{
				$errorMsg = 'Error '.mysqli_error($conn);
			}
		}
  }
?>
