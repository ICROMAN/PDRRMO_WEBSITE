<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];

		$sql = "DELETE FROM activity_records WHERE id in ($id)";
		$result = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

