
	$(document).on("click", ".restore", function() { 
		var id=$(this).attr("data-id");
		$('#id_r').val(id);
		
	});
	$(document).on("click", "#restore", function() { 
		$.ajax({
			url: "backend/save.php",
			type: "POST",
			cache: false,
			data:{
				type:3,
				id: $("#id_r").val()
			},
			success: function(dataResult){
					$('#restoreArchiveModal').modal('hide');
					$("#"+dataResult).remove();
					location.reload();
			
			}
		});
	});

	$(document).on("click", ".delete", function() { 
		var id=$(this).attr("data-id");
		$('#id_d').val(id);
		
	});
	$(document).on("click", "#delete", function() { 
		$.ajax({
			url: "backend/save.php",
			type: "POST",
			cache: false,
			data:{
				type:4,
				id: $("#id_d").val()
			},
			success: function(dataResult){
					$('#deleteArchiveModal').modal('hide');
					$("#"+dataResult).remove();
					location.reload();
			
			}
		});
	});
	