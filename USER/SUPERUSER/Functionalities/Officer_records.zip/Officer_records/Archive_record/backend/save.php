<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];

		$sql = "INSERT INTO `staff_records` (fname, lname, position, image)
				SELECT fname, lname, position, image FROM archived_staff WHERE id=$id";

		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('SYSTEM ADMIN', 'Restored Officer Record')";
		$result1 = mysqli_query($conn, $sql);

		$sql = "DELETE FROM `archived_staff` WHERE id=$id ";
		$result2 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];

		$sql = "DELETE FROM `archived_staff` WHERE id=$id ";
		$result = mysqli_query($conn, $sql);

		$sql = "INSERT INTO `activity_records`(`name`, `activity_desc`) 
		VALUES ('SYSTEM ADMIN', 'Deleted Officer Record')";
		$result1 = mysqli_query($conn, $sql);

		if ($result) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>

