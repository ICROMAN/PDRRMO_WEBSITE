<?php
require_once "DatabaseBackup.php";

$databaseBackup = new DatabaseBackup();

if(!empty($_POST["table"]) && count($_POST["table"]) > 0) {
    $databaseBackup->backupDatabase($_POST["table"]);
}

$tables = $databaseBackup->getAllTable();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ADMIN | Database Backup</title>
    <link rel="icon" type="image/ico" href="../../pdrrmo.png">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800;900&display=swap');
        html,body{
            font-family: 'Montserrat', sans-serif;
        }
        
        @media screen and (max-width:990px){
            .counter{ margin-bottom: 40px; }
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php 
            include_once "sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">SYSEM ADMIN ACCOUNT</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Basic Card Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h3 class="m-0 font-weight-bold text-primary">Manage Database Backup Records</h3>
                        </div>
                        <div class="card-body">
                            <!-- Row -->
                    <div class="table-struct full-width full-height">
                        <div class="table-cell vertical-align-middle auth-form-wrap">
                            <div class="auth-form  ml-auto mr-auto no-float">
                                <div class="row">
                                    <div class="col-sm-12 col-xs-12">
                                        <div class="form-wrap">
                                            <form action="database_backup.php" method="post" id="">
                                                <div class="form-group">
                                                    <label class="control-label mb-10" >Host</label>
                                                    <input type="text" class="form-control" placeholder="Enter Server Name EX: Localhost" name="server" id="server" required="" autocomplete="on">
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label mb-10" >Database Username</label>
                                                    <input type="text" class="form-control" placeholder="Enter Database Username EX: root" name="username" id="username" required="" autocomplete="on">
                                                </div>
                                                <div class="form-group">
                                                    <label class="pull-left control-label mb-10" >Database Password</label>
                                                    <input type="password" class="form-control" placeholder="Enter Database Password" name="password" id="password" >
                                                </div>
                                                <div class="form-group">
                                                    <label class="pull-left control-label mb-10">Database Name</label>
                                                    <input type="text" class="form-control" placeholder="Enter Database Name" name="dbname" id="dbname" required="" autocomplete="on">
                                                </div>
                                                <div class="form-group text-center">
                                                    <button type="submit" name="backupnow" class="btn btn-primary btn-rounded">Initiate Backup</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /Row -->
                        </div>
                    </div>

                </div>
                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-default" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="../../../../LOGIN/logout-user.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="jquery-3.2.1.min.js" type="text/javascript"></script>
    <script>
    $(document).ready(function () {
    $("#checkbox-header").on("change", function() {
        if ($(this).is(':checked')) {
           $(".checkbox-input").prop("checked",true);
        } else {
               $(".checkbox-input").prop("checked",false);
        }
    });

    });
    function validateCheckbox() {
        var valid = true;
        var checkedLength = $(".checkbox-input:checked").length;
        if(parseInt(checkedLength) <= 0) {
            $("#error-message").show();
            $("#error-message").html("Check atleast 1 Table to Export");
            valid= false;
        }
        if(valid) {
            $(".checkbox-input").each(function(){
                if($(this).prop("checked") == true) {
                        var tableName = $(this).data("table-name");
                    $(this).next(".checkbox-tablename").val(tableName);
                } else {
                    $(this).next(".checkbox-tablename").val("");
                }
            });
        }
        return valid;
    }
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>